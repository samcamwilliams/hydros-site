#ifndef INET_H
#define INET_H

STUBH(htonl, (uint32_t hostlong), uint32_t);
STUBH(htons, (uint16_t hostshort), uint16_t);
STUBH(ntohs, (uint16_t netshort), uint16_t);

#endif
