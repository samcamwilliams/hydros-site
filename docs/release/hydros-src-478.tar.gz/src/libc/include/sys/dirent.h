#ifndef SYS_DIRENT_H
#define SYS_DIRENT_H

#include <dirent.h>

#endif
