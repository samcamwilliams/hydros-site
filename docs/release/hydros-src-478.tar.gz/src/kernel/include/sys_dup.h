#ifndef SYS_DUP_H
#define SYS_DUP_H

void sys_dup_kernel(char* location);
void sys_dup_all_kernels(void);

#endif
