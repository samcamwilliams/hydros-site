/* This file handles settings up a single page (for now) for each of the APs.
 * We then set the the other processors to use these pages as thier *S reg values.
 * Hopefully this avoids problems with code relocation. */

#include <paging.h>
#include <types.h>
#include <port.h>
#include <byte_utils.h>
#include <apic.h>
#include <console.h>
#include <memory.h>
#include <debug.h>
#include <system.h>
#include <math.h>

#define NUM_BSP_PAGES 511

int get_memory_limit(void) {
	// For now return a static vlaue.
	// TODO: We will sort out detecting this properly later.
	return system_get_memory(); // RAM Size in KB
}

int pages_per_processor(void) {
	// TODO: This is slightly broken.
	return get_memory_limit() / ((system_get_cores() * 2) * 1024);	
} 

void create_page_entry(u64int* page_ptr, int entry, u64int dest_addr) {
	*((u64int*)(page_ptr + entry)) = dest_addr + 3; // Make the page entry
}

u64int create_page(u64int* page_ptr, u64int dest_addr) {
	int i;

	for(i = 0; i < 512; i++, dest_addr += 0x1000) {
		//console_printf(
			//"Page pointer: %h, Entry: %h, Destination address: %h\n",
			//page_ptr, i, dest_addr);
		create_page_entry(page_ptr, i, dest_addr);
	}

	return dest_addr; // Return the last address that was paged
}

void create_page_directory_entry(
		u64int* page_table_ptr,
		int entry,
		u64int dest_addr) {
	*(page_table_ptr + entry) = dest_addr + 3;
}

void create_page_directory(
		u64int* page_directory_ptr,
		u64int* pages_ptr,
		u64int dest_addr,
		int entries) {
	int i;

	for(i = 0; i < entries; i++) {
		dest_addr = create_page((u64int*) (pages_ptr + (512 * i)), dest_addr);
		create_page_directory_entry(
			page_directory_ptr,
			i,
			(u64int)pages_ptr + (512 * i * 8)
		);
	}
}

void remove_from_page_directory(u64int* page_directory_ptr, int entries) {
	kmemset((char*) page_directory_ptr, 0, entries * 8);
}

void page_lapic_area(u64int base) {
	u64int* pdpt = (u64int*) (base + 0x2000);
	u64int* pd = (u64int*) (base + 0x92000);
	u64int* pt = (u64int*) (base + 0x93000); // For the local APIC
	u64int* pt2 = (u64int*) (base + 0x94000); // For the I/O APIC.

	//console_printf("Paging the LAPIC and IOAPIC areas at %h.\n", base);

	//BREAK();

	pt[0] = 0xfee00003;
	pt2[0] = 0xfec00003;
	pd[502] = 0x94003;
	pd[503] = 0x93003;
	pdpt[3] = 0x92003;
}

void paging_bsp_setup(void) {
	// Setup the page tables for the BSP.
	// This processor has to have access to all of memory so it can make 
	// copies of the kernel
	u64int* pd = (u64int*) 0x3000; // Create a pointer to the page directory
	int mem_limit = get_memory_limit();
	u64int addr = 0x200000;
	pd++; // Start from the second entry of the page directory
	u64int** pages_ptr = (u64int**) 0x800000;
	int pages = min(NUM_BSP_PAGES, (mem_limit / (0x200000 / 1024)) + 1);

	// TODO: URGENT - This breaks during the 138th page creation.
	// Variables become corrupted.

	console_printf("Setup paging for BSP to access first %dmb.\n", pages * 2);
	create_page_directory(pd, (u64int*) pages_ptr, addr, pages);

	page_lapic_area(0);
}

void paging_bsp_setup_stage2(void) {
	// TODO: This leaves a small area paged for each CPU.
	u64int* pd = (u64int*) 0x3000;
	int required = pages_per_processor();

	remove_from_page_directory((pd + required + 1), 512 - (required + 1));

}

void prepare_meta_table(void) {
	// Zero the meta table
	kmemset((char *) 0x500, 0, 8 * SYS_MAX_CORES);
}

void paging_identity_map(u64int base_addr, u64int addr) {
	*((u64int*) (base_addr + 0x3000 + ((addr / 4096) * 8)))
		= (u64int) (addr + 3);
}

void paging_ap_setup(void) {
	// Setup the page tables for each AP
	u64int ram_total, ram_each, base_addr, addr;
	int procs = system_get_cores(), proc_iter = 1;
	// First, get the maximum amount of RAM available to us
	ram_total = get_memory_limit() * 1024;
	ram_each = ram_total / procs;
//	ram_each = 32 * 1024 * 1024;

	// Set the first entry in the paging meta-table to point to the basic 
	// low memory page table.
	*((u32int *) 0x500) = 0x1000;

	console_printf("Detected %dmb RAM to share between %d processors.\n",
		(ram_total/(1024 * 1024)), procs);
	console_printf(
		"Each core will be allocated %dmb of RAM\n",
		(ram_each/(1024 * 1024)));

	// Create a page table and directory for each AP.
	
	while(proc_iter < procs) {
		// At the moment, we only give each processor 2mb to play with.
		base_addr = util_align_up(ram_each * proc_iter, 0x1000);
		addr = base_addr;

		kmemset((char*) base_addr, 0, 0x4000);
		kmemset((char*) (base_addr + 0x92000), 0, 0x4000);

		console_printf(
			"Putting page tabs for core %d at address %h.\n",
			proc_iter, base_addr);


		// Set the PML4T to point to the PDPT
		*((u64int *) addr) = (addr + 0x1000) + 3; 
		addr += 0x1000;

		*((u64int *) addr) = (addr + 0x1000) + 3; // PDPT -> PDT
		addr += 0x1000;

		page_lapic_area(base_addr);

		*((u64int *) addr) = (addr + 0x1000) + 3; // PDT -> PT
		
		addr = base_addr + 0x3000;

		// Fill the page table
		create_page((u64int*) addr++, base_addr);

		// Manually map the 4kb at the video memory, local APIC and
		// the shared memory area to offset 0.
		paging_identity_map(base_addr, 0x5000); 
		// The shared information area requires two 4kb pages as it
		// cannot be 4kb aligned.
		paging_identity_map(base_addr, 0xb000); 
		paging_identity_map(base_addr, 0xb8000);
		// Page the location of the AP boot code, so that the CPU
		// does not jump when the page tables are loaded
		paging_identity_map(base_addr, 0xc000);

		// Create pages for the working memory of the AP
		// Ignore the first entry in the page directory
		// Put the pages in the same place as they are for BSP
		create_page_directory(					
			(u64int*) (base_addr + 0x2000 + 8),	
			(u64int*) base_addr + 0x800000,		
			base_addr + 0x200000, 
			pages_per_processor()
		);

		// Placing proc_id at 0xC0000
		*((char*)(base_addr + 0xC0000)) = (char) proc_iter;
		
		// Add a paging meta-table entry for this processor.
		
		addr = (0x500) + (proc_iter * 4);

		console_printf(
			"Produced page tables. Setting %h to point to start (%h).\n",
			addr,
			base_addr
		);

		// At 0x500 we make a list of the start locations of RAM for each proc.
		*((u32int *) addr) = base_addr;

		proc_iter++;
	}
}
