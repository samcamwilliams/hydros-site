/* Functions that interact with PIDs in ways that
 * we cannot do from Erlang */

#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#include "sys.h"
#include "erl_vm.h"
#include "global.h"
#include "erl_process.h"
#include "error.h"
#include "bif.h"
#include "erl_binary.h"
#include "erl_bits.h"
#include "erl_term.h"

BIF_RETTYPE os_process_get_node_id_1(BIF_ALIST_1) {
	if(is_small(BIF_ARG_1))
		BIF_RET(make_small(BIF_ARG_1));
	else
		BIF_RET(make_small((_GET_PID_DATA(BIF_ARG_1)) >> NODE_DATA_OFFSET));
}
