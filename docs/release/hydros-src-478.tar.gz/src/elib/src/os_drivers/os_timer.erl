-module(os_timer).
-export([start/0]).

%%% Configure and start the timer subsystem.

start() ->
	Start = os_system_info:get_lapic_counter(),
	os_lapic:init_timer(16#C00),
	os_pit:set_timer(100),
	os_pit:enable(),
	os_unsafe:instruction(sti),
	os_util:until(
		fun() ->
			os_system_info:get_pit_counter() >= 100
		end
	),
	End = os_system_info:get_lapic_counter(),
	os_pit:disable(),
	os_system_info:set_time(0),
	os_system_info:set_lapic_inc(1000000 div (End - Start + 1)),
	%erlang:display({lapic_tick_us, 1000000 div (End - Start + 1)}).
	ok.
