-module(os_ioapic).
-export([id/0, arb_id/0, version/0, start/0]).
-export([enable_interrupt/1, disable_interrupt/1]).

%%% Provides an interface through which various functions of
%%% the IO APIC can be accessed.

% The location of the IOAPIC registers
-define(SELECT, 16#FEC00000).	% The register select register
-define(WIN,    16#FEC00010).	% The 'data' register
-define(REDIR_TAB, 16#10).		% The base of the redirection tables
-define(IRQ0, 16#20).			% The first IRQ
-define(INT_CPU, 0).			% CPU to which int's should be sent

%%% Public API

% Enable all of the IRQs
start() -> enable_all_interrupts().

% Get the IOAPIC ID
id() -> read(16#0) bsr 24.

% Get the IOAPIC ID
arb_id() -> read(16#2).

% Read the version of the IOAPIC.
version() -> read(16#1).

%%% Helper functions

enable_all_interrupts() ->
	lists:foreach(fun enable_interrupt/1, lists:seq(0, 15) -- exclusions()).

enable_interrupt(IRQ) ->
	io:format("Enabling interrupt ~p~n", [IRQ]),
	write(?REDIR_TAB + (2 * IRQ), ?IRQ0 + IRQ),
	write(?REDIR_TAB + (2 * IRQ) + 1, ?INT_CPU bsl 24).

% IRQs that we don't want to receive interupts from.
% Just the PIT, for now.
exclusions() -> [2].

disable_interrupt(IRQ) ->
	% TODO: Make this actually /not/ trigger an interrupt at all.
	write(?REDIR_TAB + (2 * IRQ), 0),
	ok.

% read from the IOAPIC
read(Reg) ->
	reg_write(select, << Reg >>),
	binary:decode_unsigned(os_unsafe:read(address(win), 4)).

% Write to the IOAPIC
write(Reg, Data) ->
	reg_write(select, << Reg >>),
	reg_write(win, << Data >>).

%% Write to the register
reg_write(Addr, Bin) ->
	os_unsafe:write(address(Addr), bin_rev(Bin), 32).

address(select) -> ?SELECT;
address(win) -> ?WIN.

% This really should not be necessary!
bin_rev(X) -> bin_rev(X, <<>>).
bin_rev(<<>>, Acc) -> Acc;
bin_rev(<<H:1/binary, Rest/binary>>, Acc) ->
    bin_rev(Rest, <<H/binary, Acc/binary>>).
