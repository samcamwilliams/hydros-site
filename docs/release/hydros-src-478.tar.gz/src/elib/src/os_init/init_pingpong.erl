-module(init_pingpong).
-export([start/0, requires/0, only_core/0]).
-export([server/0, server/1]).

start() ->
	% Spawn the pingpong servers
	RemotePID = os_ipc:spawn(0, fun server/0, []),
	LocalPID = spawn(fun server/0),
	% Ping the remote server, with a return PID of the local server
	ping(RemotePID, LocalPID),
	ok.


server() -> server(0).
server(X) ->
	receive
		{ping, PID} ->
			os_util:wait(100000),
			ping(PID),
			erlang:display({pinged, X}),
			server(X + 1)
	end.

ping(PID) -> ping(PID, self()).
ping(PID, Self) ->
	os_ipc:send(PID, {ping, Self}).

requires() ->
	[init_ipc].

only_core() -> 1.
