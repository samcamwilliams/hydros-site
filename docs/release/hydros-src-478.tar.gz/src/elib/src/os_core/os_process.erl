-module(os_process).
-export([get_node_id/1]).

get_node_id(_PID) -> erlang:nif_error(undefined).
