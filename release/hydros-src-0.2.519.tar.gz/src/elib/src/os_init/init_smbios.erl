-module(init_smbios).
-export([start/0, requires/0]).

start() ->
	os_smbios:start().

requires() -> [init_sdict].
