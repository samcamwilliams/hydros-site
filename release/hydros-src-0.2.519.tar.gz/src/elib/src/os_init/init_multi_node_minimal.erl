-module(init_multi_node_minimal).
-export([start/0, requires/0, only_core/0]).

start() ->
	% Start all other APs.
	%os_mp_start:all().
	ok.

requires() ->
	[].

only_core() -> 0.
