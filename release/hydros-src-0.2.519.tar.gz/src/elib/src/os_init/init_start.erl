-module(init_start).
-export([start/0]).

start() ->
	os_debug:log("HydrOS is booting..."),
	io:format("Starting node ~p of ~p.~n",
		[
			os_system_info:get_proc_id(),
			os_system_info:get_num_procs()
		]
	),
	ok.
