-module(init_cli).
-export([start/0, requires/0, only_core/0]).

start() ->
	os_read_keyboard:start(),
	os_simple_console:start().

requires() -> [ init_keyboard, init_time, init_normal ].

only_core() -> 0.
