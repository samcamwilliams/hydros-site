-module(init_apic).
-export([start/0, requires/0, only_core/0]).

start() ->
	os_apic:start().

requires() -> [ init_interrupts ].

only_core() -> 0.
