-module(os_unsafe).
-export([read/2, write/2, write/3]).
-export([lock/1, unlock/1]).
-export([port_in/1, port_out/2]).
-export([port_in32/1, port_out32/2]).
-export([interrupt/0, get_sys_val/1, instruction/1]).
-export([format/1, print_string/1]).
-export([hang/0]).

read(_Addr, _Len) -> erlang:nif_error(undefined).

write(_Addr, _Bin) -> erlang:nif_error(undefined).
write(_Addr, _Bin, _CopySize) -> erlang:nif_error(undefined).

lock(_Addr) -> erlang:nif_error(undefined).

unlock(_Addr) -> erlang:nif_error(undefined).

port_in(_Addr) -> erlang:nif_error(undefined).

port_out(_Addr, _Data) -> erlang:nif_error(undefined).

port_in32(_Addr) -> erlang:nif_error(undefined).
port_out32(_Addr, _Data) -> erlang:nif_error(undefined).

interrupt() -> erlang:nif_error(undefined).

get_sys_val(_Type) -> erlang:nif_error(undefined).

instruction(_Name) -> erlang:nif_error(undefined).

format(_) -> erlang:nif_error(undefined).

hang() -> ?MODULE:instruction(hang).

print_string(_) -> erlang:nif_error(undefined).
