-module(os_debug).
-export([log/1, log/2, console_write/1, console_write_char/1, break/0, rdtsc/0]).
-export([hlt/0]).
-export([p/1, p/2, print_obj/1, print_obj/2]).

%% A basic 'log and print' function.
p(X) -> print_obj(X).
p(Str, Xs) -> print_obj(Str, Xs).

print_obj(X) ->
	erlang:display({debug, self(), X}),
	X.

%% io:format version.

%print_obj(X) -> print_obj("~p", [X]).
print_obj(Str, X) when not is_list(X) -> print_obj(Str, [X]);
print_obj(Str, Xs) ->
	io:format(
		"[Debug]{~p} " ++ Str ++ "~n.",
		[self()] ++ Xs
	).

log(Str) -> log(Str, []).
log(Fmt, Args) ->
	console_write(
		"[HydrOS:"
			++ integer_to_list(os_system_info:get_proc_id())
			++ "] "
			++ lists:flatten(io_lib:format(Fmt, Args))
			++ "\n"
	).

console_write([]) -> ok;
console_write([C|Str]) ->
	console_write_char(C),
	console_write(Str).

console_write_char(C) ->
	os_unsafe:port_out(16#e9, C).

break() -> os_unsafe:instruction(break).

rdtsc() ->
	{High, Low} = os_unsafe:instruction(rdtsc),
	(High bsl 32) bor Low.

hlt() -> os_unsafe:instruction(hlt).
