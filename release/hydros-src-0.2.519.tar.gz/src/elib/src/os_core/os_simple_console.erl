-module(os_simple_console).
-export([start/0]).
-record(key, {
	key_characters,
	key_down,
	type
}).
%%% A basic REPL for the OS.
%%% Listens to the keyboard for input, reads it into a string until it receives
%%% an enter. Once enter has been received, it parses the string and executes
%%% it with the same bindings as the previous command.

-record(state, {
	string = "",
	bindings = erl_eval:new_bindings()
}).

start() ->
	register(?MODULE, PID = spawn(fun start_server/0)),
	PID.

new_prompt() -> io:format(":- ").

start_server() ->
	io:format(
		"~n~n"
		"          WELCOME TO HYDROS~n~n"),
	new_prompt(),
	set_cursor(),
	server(#state{}).

server(S) ->
	receive
		{input, RawKeys} ->
			Key = process_keys(RawKeys),
			NewState = handle_key(S, Key),
			set_cursor(),
			server(NewState)
	end.

process_keys(Keys) ->
	{XKeys, Mods} =
		lists:splitwith(
			fun(#key{ type = Type }) -> Type =/= mod end,
			Keys
		),
	generate_char(XKeys, Mods).

generate_char([], [Mod|_]) ->
	hd(Mod#key.key_characters);
generate_char([Key|_], Mods) ->
	case {Key#key.key_characters, Mods} of
		{[{C, _}], _} -> C;
		{[C], _} -> C;
		{[C,_], []} -> C;
		{[_, C], _} -> C
	end.

%% Execute the command on enter
handle_key(S = #state { string = Str, bindings = Bnds }, enter) ->
	S#state { string = "", bindings = execute_string(Str, Bnds) };
%% Remove the last character on backspace.
handle_key(S = #state { string = Str }, bksp) when length(Str) > 0 ->
	io:format("\b"),
	S#state {
		string = lists:reverse(tl(lists:reverse(Str)))
	};
%% Ignore other control characters.
handle_key(S, X) when is_atom(X) -> S;
%% Print any non-control characters and add the character to the command.
handle_key(S = #state { string = Str }, Char) ->
	io:format("~s", [[Char]]),
	S#state { string = Str ++ [Char] }.

execute_string("", Bnds) ->
	io:format("~n"),
	new_prompt(),
	Bnds;
execute_string(Str, Bnds) ->
	io:format("~n"),
	try do_exec(Str, Bnds) of
		{Res, NewBnds} ->
			io:format("~p~n", [Res]),
			new_prompt(),
			NewBnds
	catch
		Type:Details ->
			io:format("~p: ~p~n", [Type, Details]),
			new_prompt(),
			Bnds
	end.

do_exec(String, Bindings) ->
	{ok, Tokens, _} = erl_scan:string(String),
	ASTRes =  erl_parse:parse_exprs(Tokens),
	{ok, AST} = ASTRes,
	Result = erl_eval:exprs(AST, Bindings),
	{value, Res, NewBindings} = Result,
	{Res, NewBindings}.

get_cursor() ->
	os_unsafe:get_sys_val(cursor).

set_cursor() ->
	{X, Y} = get_cursor(),
	os_cursor:move_to(X, Y).
