-module(os_keyboard).
-export([start/0, add_listener/1, add_exclusive_listener/1]).
-export([remove_listener/1]).

-record(state, {
	listeners = [],
	exclusive = undefined,
	last = 0
}).

start() ->
	register(?MODULE, PID = spawn(fun() -> server(#state{}) end)),
	os_interrupts:add_listener(16#21, PID),
	PID.

add_listener(PID) ->
	?MODULE ! {add, PID},
	ok.

add_exclusive_listener(PID) ->
	?MODULE ! {add_exclusive, PID},
	ok.

remove_listener(PID) ->
	?MODULE ! {remove, PID},
	ok.

server(S) ->
	receive
		{add, PID} ->
			server(S#state { listeners = [PID|S#state.listeners] });
		{add_exclusive, PID} ->
			server(S#state { exclusive = PID });
		{remove, PID} ->
			server(
				case S#state.exclusive of
					PID -> S#state { exclusive = undefined };
					_ ->
						S#state {
							listeners = 
								lists:filter(
									fun(XPID) -> PID == XPID end,
									S#state.listeners
								)
						}
				end
			);
		{interrupt, 16#21, _, _ } ->
			New = read(),
			inform_listeners(S, New),
			server(S#state { last = New })
	end.

inform_listeners(#state{ exclusive = PID }, Code) when PID =/= undefined ->
	PID ! {scancode, Code};
inform_listeners(#state{ listeners = Ls }, Code) ->
	lists:foreach(fun(PID) -> PID ! {scancode, Code} end, Ls).

read() -> os_unsafe:port_in(16#60).
