-module(os_multiconsole).
-export([start/0, start/2, write/1, clear/0, server/1]).
%-compile(export_all).

%% Data definitions

-define(VID_MEM, 16#b8000).
-define(TEXT_ATTRS, [16#1B, 16#4F, 16#74, 16#6B, 16#41]).
-define(VID_WIDTH, 80).
-define(VID_HEIGHT, 25).

%% Server state record
%% The defaults represent a single output console
-record(state, {
	id = 1,
	consoles = 1,
	width = ?VID_WIDTH,
	height = ?VID_HEIGHT,
	start_x = 0,
	start_y = 0,
	cursor_x = 0,
	cursor_y = 0,
	text_attr = hd(?TEXT_ATTRS)
}).

%%% TODO: Fix the problem with the right hand side of the output.

%% Start a single console output
start() -> start(1, 1).

%% Start and register the console output
start(ID, Consoles) ->
	register(?MODULE, spawn(?MODULE, server, [make_state(ID, Consoles)])).

%% We present as a normal terminal if only one core is using the output
make_state(1, 1) -> #state{};
%% In all other cases, make two columns and split them into segments.
make_state(ID, Consoles) ->
	Width = ?VID_WIDTH div 2,
	Height = ?VID_HEIGHT div (Consoles div 2),
	#state {
		id = ID,
		consoles = Consoles,
		width = Width,
		height = Height,
		start_x = case ID rem 2 of 1 -> 0; 0 -> Width end,
		start_y = (ID div 2) * Height,
		text_attr = lists:nth((ID rem length(?TEXT_ATTRS)) + 1, ?TEXT_ATTRS)
	}.

%% Message wrapper functions

write(String) -> ?MODULE ! {write, String}.

clear() -> ?MODULE ! clear.

%% The main console server
server(S) ->
	receive
		{write, Str} -> server(write_string(S, Str));
		clear -> server(clear(S))
	end.

%% Write a string on the console and update the state
write_string(S, Str) ->
	lists:foldl(
		fun(Char, XS) -> write_char(XS, Char) end,
		S,
		Str
	).

%% Write a character and update the state
write_char(S = #state { width = W, cursor_x = X }, $\n) ->
	% Create a new line by filling the row with spaces
	write_string(S, [ $  || _ <- lists:seq(0, W - X) ]);
write_char(S, Char) ->
	write_char_abs(Char, S#state.text_attr, rel_to_abs_pos(S)),
	increment_pos(S).

%% Write a character at an absolute location on the console
write_char_abs(C, TextAttr, {X, Y}) ->
	write_char_abs(C, TextAttr, X, Y).
write_char_abs(C, TextAttr, X, Y) ->
	os_unsafe:write(
		abs_pos_to_addr(X, Y),
		<<C, TextAttr>>
	).
	%ok.

%% Increment the position indicated by the state by one character
increment_pos(
	S = #state {
		cursor_x = X,
		width = Width
	}) when (X + 1) >= Width ->
	increment_line(S);
increment_pos(S = #state { cursor_x = X }) ->
	% We just need to move one character along
	S#state { cursor_x = X + 1 }.

% Increment the line of the cursor
increment_line(
	S = #state {
		width = Width,
		height = Height,
		cursor_y = CursorY,
		start_x = StartX,
		start_y = StartY,
		text_attr = TextAttr }) when CursorY >= Height ->
	% Scroll the console.
	lists:foreach(
		fun(Row) ->
			os_unsafe:write(
				abs_pos_to_addr(rel_to_abs_pos(StartX, StartY, 0, Row - 1)),
				get_row(rel_to_abs_pos(StartX, StartY, 0, Row), Width)
			)
		end,
		lists:seq(1, Height)
	),
	% Remove the contents of the current line
	clear_row(StartX, StartY, Width, TextAttr, Height),
	% Update and return the state
	S#state { cursor_x = 0, cursor_y = Height};
increment_line(S = #state{ cursor_y = Y }) ->
	S#state { cursor_x = 0, cursor_y = Y + 1 }.

%% Fill a row with spaces
clear_row(StartX, StartY, Width, TextAttr, Row) ->
	lists:foreach(
		fun(SpaceX) ->
			write_char_abs(
				$ ,
				TextAttr,
				rel_to_abs_pos(StartX, StartY, SpaceX, Row)
			)
		end,
		lists:seq(0, Width - 1)
	).

%% Clear the entire screen
clear(
	S = #state {
		width = Width,
		height = Height,
		start_x = StartX,
		start_y = StartY,
		text_attr = TextAttr }) ->
	lists:foreach(
		fun(Row) ->
			clear_row(StartX, StartY, Width, TextAttr, Row)
		end,
		lists:seq(0, Height)
	),
	S#state { cursor_x = 0, cursor_y = 0 }.
	

%% Convert a position, indicated by a state, to an absolute co-ordinate
rel_to_abs_pos(S) ->
	rel_to_abs_pos(
		S#state.start_x,
		S#state.start_y,
		S#state.cursor_x,
		S#state.cursor_y
	).
rel_to_abs_pos(SX, SY, CX, CY) ->
	{SX + CX, SY + CY}.

%% Turn an absolute position into a memory address
abs_pos_to_addr({X, Y}) -> abs_pos_to_addr(X, Y).
abs_pos_to_addr(X, Y) -> ?VID_MEM + (X * 2) + (Y * ?VID_WIDTH * 2).

%% Takes an absolute position and width and retuns a binary for that row
get_row({X, Y}, Width) -> get_row(X, Y, Width).
get_row(X, Y, Width) ->
	os_unsafe:read(abs_pos_to_addr(X, Y), Width * 2).

