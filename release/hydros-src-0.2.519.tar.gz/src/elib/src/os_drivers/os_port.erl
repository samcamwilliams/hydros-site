-module(os_port).
-export([in/1, out/2]).

%%% Functions that interact with the system's ports.

in(Addr) -> os_unsafe:port_in(Addr).

out(Addr, Data) -> os_unsafe:port_out(Addr, Data).
