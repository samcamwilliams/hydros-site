-module(os_ipc).
-export([start/0, server/1, send/2]).
-export([spawn/1, spawn/2, spawn/3, whereis/2]).
-compile({no_auto_import, [{spawn, 1}, {spawn, 2}, {spawn, 3}]}).
-define(SHARED, [16#5000, 16#5400, 16#5800, 16#5B00]).
-define(TIMEOUT, 0).


-record(state, {
	proc_id
}).

%%% This module handles passing messages between nodes in the system
%%% and spawning processes on other nodes.

%%% The informal grammar of the node buffer format used in this file
%%% is as follows:
%%%
%%% Buffer -> Lock Messages
%%% Lock -> 8 bits
%%% Messages  -> Message Messages
%%% Messages  -> Message
%%% Message   -> EndOfList
%%% Message   -> Length TypeTag TermBin
%%% Message   -> Length TypeTag RawBin
%%% Length    -> 8 bits
%%% TypeTag   -> 8 bits
%%% TermBin   -> n*8 bits, where n is the length of the serialized term
%%% RawBin    -> n*8 bits, where n is the length of the binary data
%%% EndOfList -> 0:8 bits

%% Start the server
start() ->
	ProcID = os_system_info:get_proc_id(),
	%reset_buffer(ProcID),
	register(?MODULE,
		erlang:spawn(os_ipc, server,
			[
				#state {
					proc_id = ProcID
				}
			]
		)
	).

%% A wrapper to the send message functionality
send(ToPID, Msg) ->
	os_debug:log("SEND ~p TO ~p.", [Msg, ToPID]),
	?MODULE ! {message, ToPID, Msg}.

%% Spawn on a remote server
spawn(Fun) -> spawn(os_topology:choose_spawn_node(), Fun).
spawn(Fun, Args) when is_function(Fun) ->
	spawn(os_topology:choose_spawn_node(), Fun, Args);
spawn(ToNode, Fun) -> spawn(ToNode, Fun, []).
spawn(ToNode, Fun, Args) ->
	os_debug:log("SPAWN ~p ON ~p WITH ~p", [Fun, ToNode, Args]),
	?MODULE ! {spawn, self(), ToNode, Fun, Args},
	receive
		{spawned, Fun, Args, PID} -> PID
	end.

% A 'global' whereis server.
%whereis(Proc) when is_atom(Proc) -> whereis({local, Proc});
%whereis({N, Proc}) -> whereis(N, Proc).
whereis(local, Proc) -> erlang:whereis(Proc);
whereis(N, Name) ->
	ReplyPID = self(),
	os_debug:log("WHEREIS ~p ON ~p?", [Name, N]),
	os_ipc:spawn(N,
		fun() ->
			os_ipc:send(ReplyPID, {whereis, N, Name, whereis(Name)})
		end
	),
	receive
		{whereis, N, Name, X} -> X
	end.

% The main server loop that handles requests
server(S) ->
	receive
		{spawn, ReplyPID, Target, Fun, Args} ->
			write_message(Target, {spawn, ReplyPID, Fun, Args}, false),
			server(S);
		{message, TargetID, Msg} ->
			IsBin = is_integer(TargetID),
			write_message(
				os_process:get_node_id(TargetID),
				case IsBin of
					false -> {message, TargetID, Msg};
					true -> Msg
				end,
				IsBin
			),
			server(S)
	after ?TIMEOUT ->
		handle_buffer(S),
		server(S)
	end.

% Write a message into the appropriate buffer
write_message(TargetID, Msg, IsBin) ->
	case check_locked(TargetID) of
		true -> write_message(TargetID, Msg, IsBin);
		false ->
			set_locked(TargetID, true),
			os_unsafe:write(
				detect_buffer_free(TargetID),
				prepare_message(Msg, IsBin)
			),
			set_locked(TargetID, false)
	end.

%% Create a binary that can be appended to the list in a buffer
prepare_message(Bin, true) ->
	bin_concat(
		bin_concat(<<(size(Bin)):8, 1:8>>, Bin),
		<<0:8>>
	);
prepare_message(Msg, false) ->
	Bin = term_to_binary(Msg),
	bin_concat(
		bin_concat(<<(size(Bin)):8, 0:8>>, Bin),
		<<0:8>>
	).

%% Dirty concatenate binaries. This is slow. We should accept IO lists instead
bin_concat(B1, B2) -> <<B1/binary, B2/binary>>.

%% Find the address in the buffer to write the new message at
detect_buffer_free(TargetID) ->
	% Add one to avoid reading the lock byte (see grammar)
	Res = raw_detect_buffer_free(get_buffer(TargetID) + sizeof(lock)),
	%os_debug:log("Mail queue end: ~p.~n", [Res]),
	Res.

raw_detect_buffer_free(Addr) ->
	case os_unsafe:read(Addr, sizeof(length)) of
		<<0:8>> ->
			% Found the EndOfList symbol
			Addr;
		<<Length:8>> ->
			% Skip to the next Message symbol
			raw_detect_buffer_free(
				Addr + Length + sizeof(length) + sizeof(typetag))
	end.

%% Check whether there is anything to do with the message queue.
%% If so, handle the messages.
%% We currently don't do anything if the queue is locked, but it
%% may be appropriate in the future to wait until the lock is released
%% and check again then.
handle_buffer(S) ->
	case check_locked(S) of
		false -> process_messages(parse_raw_messages(S));
		true -> locked
	end.

%% Perform the tasks described in messages that have been read
%% from the buffer.
process_messages(Msgs) ->
	lists:map(fun process_message/1, Msgs).

process_message({spawn, ReplyPID, Fun, Args}) ->
	os_ipc:send(ReplyPID,
		{spawned,
			Fun,
			Args,
			erlang:spawn(fun() -> erlang:apply(Fun, Args) end)
		}
	);
process_message({message, TargetPID, Msg}) ->
	TargetPID ! Msg.

%% Check the status of the buffer pointed to by the process ID
check_locked(S) when is_record(S, state) -> check_locked(S#state.proc_id);
check_locked(ProcID) ->
	<<1:8>> == os_unsafe:read(get_buffer(ProcID), 1).

%% Set the buffer status for the process as locked
set_locked(S, State) when is_record(S, state) ->
	set_locked(S#state.proc_id, State);
set_locked(ProcID, true) ->
	os_util:until(
		fun() ->
			os_unsafe:lock(get_buffer(ProcID))
		end
	);
set_locked(ProcID, false) ->
	os_unsafe:unlock(get_buffer(ProcID)).

%% Get the messages from the buffer and parse them
parse_raw_messages(S) when is_record(S, state) ->
	parse_raw_messages(S#state.proc_id);
parse_raw_messages(ProcID) ->
	set_locked(ProcID, true),
	Msgs = do_parse_raw_messages(get_buffer(ProcID) + sizeof(lock)),
	case Msgs of
		[] -> ok;
		_ -> 
			%io:format("Got messages: ~p.~n", [Msgs])
			ok
	end,
	reset_buffer(ProcID),
	set_locked(ProcID, false),
	case Msgs of
		[] -> do_nothing;
		_ -> os_debug:log("RECVD ~p.", [Msgs])
	end,
	Msgs.

%% From an address, produce a list of messages
do_parse_raw_messages(Addr) ->
	case os_unsafe:read(Addr, sizeof(length)) of
		<<0:8>> -> [];
		<<Length:8>> ->
			[
				case os_unsafe:read(Addr + sizeof(length), sizeof(typetag)) of
					<<0:8>> ->
						%io:format("length: ~p~n", [Length]),
						binary_to_term(
							os_unsafe:read(Addr
								+ sizeof(length) + sizeof(typetag), Length));
					<<1:8>> ->
						read_binary_msg(Addr
							+ sizeof(length) + sizeof(typetag), Length)
				end
			|
				do_parse_raw_messages(
					Addr + Length + sizeof(length) + sizeof(typetag))
			]
	end.

%% Read the address PID and message
read_binary_msg(Addr, Len) ->
	PIDSize = byte_size(self()),
	{message,
		binary_to_term(os_unsafe:read(Addr, PIDSize)),
		os_unsafe:read(Addr + PIDSize + 1, Len)
	}.

%% Truncate the list of messages to zero.
reset_buffer(S) when is_record(S, state) -> reset_buffer(S#state.proc_id);
reset_buffer(ProcID) ->
	os_unsafe:write(get_buffer(ProcID) + sizeof(lock), <<0:8>>).

%% Get the address of the buffer for a given target
get_buffer(X) -> 
	lists:nth(X + 1, ?SHARED).

sizeof(typetag) -> 1;
sizeof(length) -> 1;
sizeof(lock) -> 1.
