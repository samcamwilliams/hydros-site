-module(os_pit).
-export([enable/0, disable/0, set_timer/1, one_shot/1, check_one_shot/0]).

-define(FREQ, 1193182).

%%% A module that supplies basic support for basic
%%% Programmable Interval Timer operation.

enable() -> os_ioapic:enable_interrupt(2).

disable() -> os_ioapic:disable_interrupt(2).

% Set the timer to interrupt X timers per second
set_timer(X) ->
	os_port:out(16#43, 16#34), % Counter 0, rategen, 16bit
	os_port:out(16#40, timer_div(X) rem 256),
	os_port:out(16#40, timer_div(X) div 256).

timer_div(X) -> (?FREQ + X) div X.

one_shot(Div) ->
	os_port:out(16#43, 16#30),
	os_port:out(16#40, 16#A9),
	os_port:out(16#40, Div).


check_one_shot() ->
	os_port:out(16#43, 16#E2),
	(os_port:in(16#40) band 64) =/= 0.


