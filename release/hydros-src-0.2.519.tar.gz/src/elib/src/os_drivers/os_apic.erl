-module(os_apic).
-export([start/0]).

%%% This module handles starting the apic subsystem.
%%% This task must only be completed on the first subnode
%%% to come up.

start() ->
	os_unsafe:instruction(cli),
	os_pic:disable(),
	os_pic:eoi(),
	os_lapic:start(),
	os_ioapic:start(),
	os_unsafe:instruction(sti).


