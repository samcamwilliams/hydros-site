#ifndef SYS_INFO_H
#define SYS_INFO_H

void sys_info_print_types(void);

#endif
