int proc_id;

void print_string(char* str) {
	char *screen = (char*) 0xb8000;
	while(*str) {
		*screen++ = *str++;
		*screen++ = 0x56;
	}
}

int main(int p_id) {
    volatile char *video = (volatile char*)0xB8000;
	char* string = "HELLO";
	proc_id = p_id;

	while(1)
		print_string(string);

	return 0;
}
