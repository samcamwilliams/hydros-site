#include <stub.h>
#include <sys/types.h>

STUBQ(setlocale, (int category, const char *locale), char *, NULL);
