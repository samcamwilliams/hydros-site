# HydrOS: A scalable many-core Operating System #

This project is under active development.
