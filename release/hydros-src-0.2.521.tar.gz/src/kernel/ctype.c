char isdigit(char x) {
	return (x > 47) && (x < 58);
}
