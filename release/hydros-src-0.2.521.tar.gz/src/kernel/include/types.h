#ifndef TYPES_H
#define TYPES_H

typedef unsigned char u8int;
typedef unsigned short u16int;
typedef unsigned int u32int;
typedef unsigned long u64int;

#endif
