void mp_start(void);
void mp_start_bootstrap(void);
void mp_init(void);
void mp_print_details(void);

void apic_start(void);
void apic_set_id(int);
