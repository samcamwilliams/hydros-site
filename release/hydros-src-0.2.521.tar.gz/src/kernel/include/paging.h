#ifndef PAGING_H
#define PAGING_H

void paging_ap_setup(void);
void paging_bsp_setup(void);
void paging_bsp_setup_stage2(void);

#endif
