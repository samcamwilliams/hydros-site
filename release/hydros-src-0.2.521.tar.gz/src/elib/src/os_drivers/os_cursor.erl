-module(os_cursor).
-export([move_to/2]).

%%% A module that handles moving the cursor around the screen through the
%%% VGA hardware.

move_to(Row, Col) ->
	Pos = (Row * 80) + Col,
	os_port:out(16#3D4, 16#0F),
	os_port:out(16#3D5, Pos band 16#FF),
	os_port:out(16#3D4, 16#0E),
	os_port:out(16#3D5, Pos bsr 8).
