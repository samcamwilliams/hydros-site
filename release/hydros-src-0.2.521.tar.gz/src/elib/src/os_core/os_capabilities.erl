-module(os_capabilities).
-compile({no_auto_import, spawn}).
-export([start/0, spawn/2, validate/1]).

-define(TAB, capabilities_tab).

%%% Defines the capabilities system of the operating system. This provides a
%%% mechanism of access controls for processes, creating a 'capabilites tree'
%%% in which the subtrees of any given tree have equal or fewer capabilities
%%% than thier parents.
%%%
%%% The system stores capabilities 'negatively' -- that is, the capability
%%% [] means that a process may do anything, [abc] means that a process cannot
%%% perform action 'abc'.
%%%
%%% Spawns no longer require a round of scheduling in order for the child 
%%% process to come up, this is, however, at the expense of simplicity.
%%% Now, only processes which have asked to perform some privelidged action
%%% before the cap server has registered their status are required to wait for
%%% the server to be scheduled.
%%%
%%% Roughly, this works as follows:
%%% When the spawn function is called, the spawner BIF is called directly.
%%% A 'store' message is then sent to the capabilities server and the PID
%%% is returned. If a process that has not yet been entered into the table
%%% attempts to perform a privelidged action, an 'available' message is sent
%%% to the server. Because 'store' messages are always prioritised over
%%% 'available' messages. The 'available' message will only be processed after
%%% the process's 'store' messages. Subsequently, when the 'available' message
%%% has been responded to, the store message of the process must have been
%%% processed. The (now ready) capabilites are then requested from the table.

%% Start the processing server
start() ->
	Root = self(),
	case lists:member(?MODULE, erlang:registered()) of
		true -> error(already_running);
		false -> register(?MODULE, spawn(fun() -> start_server(Root) end))
	end.

%% Setup the table, the root entry and begin execution
start_server(Root) ->
	ets:new(?TAB, [set, protected, named_table]),
	ets:insert(?TAB, {Root, []}),
	server().

%% Spawn a function with the same capabilities as the caller, minus the
%% contents of 'WoCaps'.
spawn(Fun, WoCaps) ->
	PID = spawn(Fun),
	?MODULE ! {store, self(), PID, WoCaps},
	PID.

%% Wait until the server is available to perform an action.
wait_available() ->
	?MODULE ! {available, Ref = make_ref(), self()},
	receive
		{available, Ref} -> ok
	end.

%% Respond to spawn requests. These requests muct go through this server, as
%% it alone has the ability to add/modify capabilities.
server() ->
	receive
		{store, Parent, Child, WoCaps} ->
			do_store(Parent, Child, WoCaps),
			server()
	end.

do_store(Parent, Child, WoCaps) ->
	ets:insert(?TAB, {Child, adjust(get_caps(Parent), WoCaps)}),
	receive
		{available, Ref, Child} ->
			Child ! {available, Ref}
	after 0 -> ok
	end.

%% Adjust the capabilities of a process. There is a strong likelihood that we
%% will end up making this greatly more complex in the future, hence the
%% abstraction.
adjust(Caps, WoCaps) -> Caps ++ WoCaps.

%% Retreive the capabilities for a process from the table.
get_caps(PID) ->
	case ets:lookup(?TAB, PID) of
		[{PID, Caps}] -> Caps;
		[] -> undefined
	end.

%% Check whether a process can perform the task that it is attempting to.
%% Again, these capabilites are negative -- that is, we are checking for
%% the non-existance of the entry in the list to ensure that an action
%% can be performed.
%%
%% This function will crash the process if the check fails.
validate(X) when not is_list(X) -> validate([X]);
validate(WoCaps) ->
	case get_caps(self()) of
		undefined ->
			% There is nothing currently stored for this process, wait
			% for the server to become available and try again, if that
			% fails, this is a rogue process and needs to be killed.
			wait_available(),
			case get_caps(self()) of
				undefined -> error(no_capabilities_stored);
				Caps -> do_validate(Caps, WoCaps)
			end;
		Caps -> do_validate(Caps, WoCaps)
	end.
			
%% Now that the ProcCaps and WoCaps are both in hand, actially perform
%% the test.
do_validate(ProcCaps, WoCap) ->
	case ProcCaps -- WoCap of
		ProcCaps -> ok;
		_ -> error({no_capability, WoCap})
	end.
