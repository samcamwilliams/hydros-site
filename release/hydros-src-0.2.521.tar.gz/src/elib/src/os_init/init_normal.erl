-module(init_normal).
-export([start/0, requires/0]).

start() ->
	%os_cursor:move_to(24, 79),
	os_debug:log("Normal operating mode reached.").

requires() ->
	[ init_single_node, init_multi_node ].
