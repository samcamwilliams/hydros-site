# HydrOS: A scalable many-core Operating System #

This project is under active development and is available under the GPL v3 license.
