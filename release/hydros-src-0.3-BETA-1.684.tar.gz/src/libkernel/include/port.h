#ifndef PORT_H
#define PORT_H

char port_inb(char port);
void port_outb(char port, char byte);

#endif
