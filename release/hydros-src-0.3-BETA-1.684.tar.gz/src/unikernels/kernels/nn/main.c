int kmain(int proc_id) {
	return 0;
}
